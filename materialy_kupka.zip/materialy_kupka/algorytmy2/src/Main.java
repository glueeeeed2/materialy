//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    // ============================================================
    // 1. CIĄG FIBONACCIEGO — wersja iteracyjna (nie-rekurencyjna)
    // ============================================================
    //
    // JAK DZIAŁA:
    // Ciąg Fibonacciego to sekwencja liczb, gdzie każda liczba jest
    // sumą dwóch poprzednich: 0, 1, 1, 2, 3, 5, 8, 13, 21, ...
    //
    // Zamiast wywoływać funkcję rekurencyjnie (co jest bardzo wolne),
    // przechodzimy po pętli i zapamiętujemy tylko dwie ostatnie liczby.
    // W każdej iteracji obliczamy następną jako ich sumę,
    // a potem przesuwamy „okno” o jedno miejsce w prawo.
    //
    // Przykład: a=0, b=1 → next=1 → a=1, b=1 → next=2 → a=1, b=2 → next=3 ...
    //
    // Złożoność: O(n) czas, O(1) pamięć — bardzo efektywne!

    int n = 10; // ile liczb Fibonacciego chcemy wygenerować
    IO.println("=== CIĄG FIBONACCIEGO (iteracyjny) ===");
    IO.println("Pierwsze " + n + " liczb Fibonacciego:");

    int a = 0; // pierwsza liczba ciągu
    int b = 1; // druga liczba ciągu

    for (int i = 0; i < n; i++) {
        IO.print(a + " ");
        int next = a + b; // następna liczba = suma dwóch poprzednich
        a = b;            // przesuwamy: a przyjmuje wartość b
        b = next;         // b przyjmuje nowo obliczoną wartość
    }
    IO.println();
    IO.println();


    // ============================================================
    // 2. SITO ERATOSTENESA — klasyczna wersja
    // ============================================================
    //
    // JAK DZIAŁA:
    // Sito Eratostenesa to najprostszy i najszybszy algorytm do
    // znajdowania wszystkich liczb pierwszych do danej liczby N.
    //
    // KROKI:
    // 1. Tworzymy tablicę boolean od 0 do N, wszystkie oznaczone jako true (pierwsze).
    // 2. 0 i 1 nie są pierwsze → ustawiamy false.
    // 3. Przechodzimy od 2 do √N. Jeśli liczba i jest jeszcze oznaczona jako true:
    //    - to jest liczba pierwsza!
    //    - Przechodzimy przez wszystkie wielokrotności i (i*i, i*(i+1), ...)
    //      i oznaczamy je jako false (nie-pierwsze).
    //    - Zaczynamy od i*i, bo mniejsze wielokrotności już zostały
    //      przekreślone przez mniejsze liczby pierwsze.
    // 4. Na końcu wszystkie pozycje true to liczby pierwsze.
    //
    // Przykład dla N=10:
    //   Start:   [T, T, T, T, T, T, T, T, T, T, T]
    //   i=2: przekreślamy 4,6,8,10 → [T, T, T, T, F, T, F, T, F, T, F]
    //   i=3: przekreślamy 9        → [T, T, T, T, F, T, F, T, F, T, F]
    //   √10 ≈ 3.16, więc kończymy.
    //   Pierwsze: 2, 3, 5, 7
    //
    // Złożoność: O(n log log n) czas, O(n) pamięć

    int limit = 30; // szukamy liczb pierwszych do 30
    IO.println("=== SITO ERATOSTENESA (klasyczne) ===");
    IO.println("Liczby pierwsze do " + limit + ":");

    boolean[] isPrime = new boolean[limit + 1];
    // Krok 1: zakładamy, że wszystkie są pierwsze
    for (int i = 2; i <= limit; i++) {
        isPrime[i] = true;
    }

    // Krok 2: przesiewanie — od 2 do √limit
    for (int i = 2; i * i <= limit; i++) {
        if (isPrime[i]) { // i jest liczbą pierwszą
            // Przekreślamy wszystkie wielokrotności i, zaczynając od i*i
            for (int j = i * i; j <= limit; j += i) {
                isPrime[j] = false;
            }
        }
    }

    // Krok 3: wypisujemy liczby pierwsze
    for (int i = 2; i <= limit; i++) {
        if (isPrime[i]) {
            IO.print(i + " ");
        }
    }
    IO.println();
    IO.println();


    // ============================================================
    // 3. SITO Z LISTĄ DZIELNIKÓW
    // ============================================================
    //
    // JAK DZIAŁA:
    // Zamiast tylko oznaczać liczby jako pierwsze/nie-pierwsze,
    // budujemy listę wszystkich dzielników dla każdej liczby.
    //
    // KROKI:
    // 1. Tworzymy tablicę list — dla każdej liczby od 0 do N
    //    mamy pustą listę dzielników.
    // 2. Przechodzimy i od 1 do N. Dla każdego i:
    //    - Dodajemy i do listy dzielników wszystkich jego wielokrotności.
    //    - Np. dla i=2: dodajemy 2 do listy 2, 4, 6, 8, 10, ...
    //    - Dla i=3: dodajemy 3 do listy 3, 6, 9, 12, ...
    // 3. Po zakończeniu każda liczba ma pełną listę dzielników.
    //    - Liczba jest pierwsza, jeśli ma dokładnie 2 dzielniki: 1 i siebie.
    //
    // Przykład dla N=6:
    //   1: dzielniki = [1]
    //   2: dzielniki = [1, 2]  → 2 dzielniki → pierwsza!
    //   3: dzielniki = [1, 3]  → 2 dzielniki → pierwsza!
    //   4: dzielniki = [1, 2, 4] → 3 dzielniki → nie-pierwsza
    //   5: dzielniki = [1, 5]  → 2 dzielniki → pierwsza!
    //   6: dzielniki = [1, 2, 3, 6] → 4 dzielniki → nie-pierwsza
    //
    // Złożoność: O(n log n) czas (każda liczba ma ~log n dzielników)

    IO.println("=== SITO Z LISTĄ DZIELNIKÓW ===");
    IO.println("Dzielniki liczb od 1 do " + limit + ":");

    // Tworzymy tablicę list dzielników
    java.util.ArrayList<Integer>[] divisors = new java.util.ArrayList[limit + 1];
    for (int i = 0; i <= limit; i++) {
        divisors[i] = new java.util.ArrayList<>();
    }

    // Dla każdej liczby i, dodajemy ją jako dzielnik wszystkich wielokrotności
    for (int i = 1; i <= limit; i++) {
        for (int j = i; j <= limit; j += i) {
            divisors[j].add(i);
        }
    }

    // Wypisujemy dzielniki i oznaczamy liczby pierwsze
    for (int i = 1; i <= limit; i++) {
        IO.print(i + ": " + divisors[i]);
        if (divisors[i].size() == 2) {
            IO.print(" (pierwsza!)");
        }
        IO.println();
    }
    IO.println();


    // ============================================================
    // 4. SORTOWANIE BINARNE (Binary Insertion Sort)
    // ============================================================
    //
    // JAK DZIAŁA:
    // To ulepszona wersja sortowania przez wstawianie (Insertion Sort).
    // Zamiast szukać miejsca na element liniowo (porównując z każdym),
    // używamy wyszukiwania binarnego, co przyspiesza znalezienie
    // właściwej pozycji.
    //
    // KROKI:
    // 1. Rozpoczynamy od drugiego elementu (indeks 1) — pierwszy jest
    //    już „posortowany”.
    // 2. Dla każdego elementu:
    //    a) Przechowujemy go w zmiennej key.
    //    b) W części już posortowanej (od indeksu 0 do i-1) szukamy
    //       miejsca dla key za pomocą wyszukiwania binarnego.
    //    c) Wyszukiwanie binarne działa tak:
    //       - Mamy lewy (left) i prawy (right) koniec zakresu.
    //       - Bierzemy środek (mid). Jeśli tab[mid] < key, szukamy
    //         w prawej połowie, inaczej w lewej.
    //       - Powtarzamy, aż znajdziemy właściwe miejsce.
    //    d) Przesuwamy elementy o jedno miejsce w prawo, by zrobić
    //       miejsce na key.
    //    e) Wstawiamy key na znalezione miejsce.
    //
    // Przykład: [5, 3, 8, 1, 2]
    //   i=1: key=3, binarne szukanie w [5] → pozycja 0
    //        → [3, 5, 8, 1, 2]
    //   i=2: key=8, binarne szukanie w [3,5] → pozycja 2
    //        → [3, 5, 8, 1, 2]
    //   i=3: key=1, binarne szukanie w [3,5,8] → pozycja 0
    //        → [1, 3, 5, 8, 2]
    //   i=4: key=2, binarne szukanie w [1,3,5,8] → pozycja 1
    //        → [1, 2, 3, 5, 8] ✓
    //
    // Złożoność: O(n²) czas (przesuwanie elementów nadal jest O(n)),
    // ale porównania to tylko O(n log n) dzięki wyszukiwaniu binarnemu.

    int[] arr = {64, 34, 25, 12, 22, 11, 90};
    IO.println("=== SORTOWANIE BINARNE (Binary Insertion Sort) ===");
    IO.println("Tablica przed sortowaniem: " + java.util.Arrays.toString(arr));

    for (int i = 1; i < arr.length; i++) {
        int key = arr[i]; // element do wstawienia
        int pos = binarySearch(arr, 0, i - 1, key); // szukamy miejsca binarnie

        // Przesuwamy elementy o jedno w prawo, od pozycji znalezionej do i-1
        for (int j = i - 1; j >= pos; j--) {
            arr[j + 1] = arr[j];
        }

        // Wstawiamy key na właściwe miejsce
        arr[pos] = key;
    }

    IO.println("Tablica po sortowaniu:     " + java.util.Arrays.toString(arr));
    IO.println();
}


// ============================================================
// POMOCNICZA FUNKCJA: Wyszukiwanie binarne
// ============================================================
// Szuka pierwszej pozycji w tab[left..right], gdzie można wstawić key,
// zachowując porządek rosnący.
// Zwraca indeks, na którym key powinien zostać umieszczony.
int binarySearch(int[] tab, int left, int right, int key) {
    // Jeśli zakres jest pusty, zwracamy left
    if (right < left) {
        return left;
    }

    while (left < right) {
        int mid = left + (right - left) / 2; // środek, unikamy overflow
        if (tab[mid] < key) {
            left = mid + 1; // key jest większy, szukamy w prawej połowie
        } else {
            right = mid;    // key jest mniejszy lub równy, szukamy w lewej
        }
    }

    // Po pętli left == right — sprawdzamy, czy key powinien iść za tab[left]
    if (left <= right && tab[left] < key) {
        return left + 1;
    }
    return left; // to jest pozycja, gdzie key ma trafić
}
